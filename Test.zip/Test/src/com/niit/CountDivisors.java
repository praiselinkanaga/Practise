package com.niit;

public class CountDivisors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int l=2;
        int r=10;
        int k=3;
        int count=0;
        for(int i=2;i<=10;i++)
        {
        	if(i%3==0)
        	{
        		count++;
        	}
        System.out.println(count);
        }
        
	}

}
