package com.niit;

import java.util.Scanner;

public class Facebook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int l;
     int d;
     Scanner sc = new Scanner(System.in);
     System.out.println("Enter no");
     l = sc.nextInt();
     d = l*l;
     
     Scanner a = new Scanner(System.in);
     System.out.println("Enter no");
     int w = a.nextInt();
     
     Scanner b = new Scanner(System.in);
     System.out.println("Enter no");
     int h = b.nextInt();
     int c = w*h;
     if(c==d)
     {
    	 System.out.println("Photo is Accepted");
    	 
     }
     else if(w!=l)
     {
    	 System.out.println("upload photo");
     }
     else if(h!=l)
     {
    	 System.out.println("upload photo");
     }
     else 
     {
    	 System.out.println("crop it");
     }
	}
	

}
