package com.niit;

public class English {
 static int i;
    
  static void changecase(String s)
    {
        for(i=0;i<s.length();i++)
        {
            int ch=s.charAt(i);
            if(ch>64&&ch<91)
            {
                ch=ch+32;
                System.out.println( (char) ch);
            }
            else if(ch>96&&ch<123)
            {
                ch=ch-32;
                System.out.println( (char) ch);
            }
            if(ch==32){
            System.out.println(" ");
            }
        }
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.println("Original String is : ");
	        System.out.println("Prayer Brings Victory");
	        English.changecase("Prayer Brings Victory");
	}

}
