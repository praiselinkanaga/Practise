package com.niit;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int i, n, f=1;
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a Number");
    n = sc.nextInt();
    for(i=1;i<=n;i++)
    {
    	f=f*i;
    }
    System.out.println("Factorial Value="+f);
	}

}
