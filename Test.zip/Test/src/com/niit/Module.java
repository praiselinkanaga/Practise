package com.niit;

public class Module {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int a[]={1,2,3,4,5,6};
      int b=1;
      int l=a.length;
      for(int i=0;i<l;i++)
      {
    	  b=b*a[i];
      }
      System.out.println(b);
	}

}
