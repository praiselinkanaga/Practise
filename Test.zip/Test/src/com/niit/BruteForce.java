package com.niit;

public class BruteForce {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a[]={1,2,22,42,99};
        int b=a.length;
        for(int i=1;i<b;i++)
        {
        	System.out.println(a[i]);
        	if(a[i]==42){
        		break;
        	}
        }
	}

}
